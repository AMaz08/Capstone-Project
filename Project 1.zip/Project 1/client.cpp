//CLIENT CODE
//client
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SERVER_IP "127.0.0.1" // Change this to the server IP address you want to connect 
to
#define PORT 9090

int main() {
 int sock;
 struct sockaddr_in server;
 char message[256];
 
 // Create socket
 sock = socket(AF_INET, SOCK_STREAM, 0);
 if (sock == -1) {
 perror("Socket creation failed");
 return 1;
 }
 
 // Configure server address
 server.sin_family = AF_INET;
 server.sin_addr.s_addr = inet_addr(SERVER_IP);
 server.sin_port = htons(PORT);
 
 // Connect to server
 if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
 perror("Connection failed");
 return 1;
 }
 printf("Connected to server\n");
 
 // Send messages to server
 while (1) {
 printf("Enter message (Q to quit): ");
 fgets(message, sizeof(message), stdin);
 
 // Send message to server
 if (send(sock, message, strlen(message), 0) < 0) {
 perror("Send failed");
 return 1;
 }
 
 // Quit on 'Q' or 'q'
 if (message[0] == 'Q' || message[0] == 'q') {
 break;
 }

 // Clear the buffer
 memset(message, 0, sizeof(message));
 
 // Receive server response
 if (recv(sock, message, sizeof(message), 0) < 0) {
 perror("Receive failed");
 return 1;
 }
 
 printf("Server response: %s\n", message);
 }
 
 // Close socket
 close(sock);
 printf("Disconnected from server\n");
 
 return 0;
}
 
